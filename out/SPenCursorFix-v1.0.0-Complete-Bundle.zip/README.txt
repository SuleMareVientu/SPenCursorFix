============================================================
S Pen Cursor Fix for LineageOS for Tablets (Android 16 / AOSP)
Version: 1.0.0
============================================================

COMPONENTS:
1. SPenCursorFix-v1.0.0-debug.apk (or release)
   - LSPosed Xposed module that hooks InputManagerService.setPointerIcon.
   - Replaces the generic desktop pointer with a solid, density-scaled
     OneUI-style circular hover dot.
   - Provides an in-app Settings UI to adjust color, radius, and allowlist.

2. spen_idc_overlay-v1.0.0.zip
   - KernelSU / Magisk module that installs /system/usr/idc/sec_e-pen.idc
     and /system/vendor/usr/idc/sec_e-pen.idc with touch.deviceType = touchScreen.
   - Shifts pointer routing in Android 16 from MousePointerController to
     native StylusPointerController, eliminating the initial hover entry and
     touch-down desktop mouse arrow cursor flashes.

INSTALLATION:
1. Install SPenCursorFix-v1.0.0-release.apk (or debug).
2. In LSPosed Manager, enable the module with scope: "System Framework" (android).
3. In KernelSU or Magisk Manager, flash spen_idc_overlay-v1.0.0.zip.
4. Reboot the tablet.
============================================================
